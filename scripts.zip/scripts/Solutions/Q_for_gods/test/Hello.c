/**
 * hello.c sample file
 */
#include <stdio.h>
#include "k.h"

int main(void){
K r;
int c=khp("10.0.2.15",1234);
 r=k(c,"0N!`Hello_world",0); 
 if (r->t==-128) printf("connection error!\n");
 else  printf("execution ok!\n");
 return 0;
}